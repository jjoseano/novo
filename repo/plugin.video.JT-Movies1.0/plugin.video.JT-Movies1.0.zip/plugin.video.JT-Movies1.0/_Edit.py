import xbmcaddon

MainBase = 'https://pastebin.com/raw/yhADPX9j'
addon = xbmcaddon.Addon('plugin.video.JT-Movies1.0')